package com.cricketlive.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF07111F)
private val Card = Color(0xFF132235)
private val Green = Color(0xFF18C784)
private val Muted = Color(0xFF9FB0C4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CricketLiveApp() }
    }
}

private data class MatchItem(
    val title: String, val status: String, val team1: String, val score1: String,
    val team2: String, val score2: String, val detail: String
)

private val demoMatches = listOf(
    MatchItem("International • Demo match", "DEMO • LIVE", "IND", "186/4 (18.2)", "AUS", "Yet to bat", "India need a strong finish"),
    MatchItem("T20 League • Demo match", "DEMO • UPCOMING", "SRH", "—", "CSK", "—", "Starts at 7:30 PM"),
    MatchItem("ODI • Demo result", "DEMO • RESULT", "ENG", "264", "NZ", "267/6", "New Zealand won by 4 wickets")
)

@Composable
private fun CricketLiveApp() {
    var selectedTab by remember { mutableStateOf("Live") }
    var selectedMatch by remember { mutableStateOf<MatchItem?>(null) }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Navy, surface = Card,
        onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Card) {
                    listOf("Live", "Upcoming", "Results").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab; selectedMatch = null },
                            icon = {
                                Icon(
                                    imageVector = when(tab) {
                                        "Upcoming" -> Icons.Default.CalendarMonth
                                        "Results" -> Icons.Default.EmojiEvents
                                        else -> Icons.Default.Home
                                    },
                                    contentDescription = tab
                                )
                            },
                            label = { Text(tab) }
                        )
                    }
                }
            }
        ) { padding ->
            if (selectedMatch != null) {
                MatchDetail(selectedMatch!!, Modifier.padding(padding)) { selectedMatch = null }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Spacer(Modifier.height(16.dp))
                        Text("CRICKET LIVE", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Green)
                        Text("Scores • Fixtures • Results", color = Muted)
                        Spacer(Modifier.height(12.dp))
                        Surface(color = Color(0xFF352B13), shape = RoundedCornerShape(10.dp)) {
                            Text(
                                "DEMO DATA — scores are examples, not live match data.",
                                modifier = Modifier.padding(12.dp),
                                color = Color(0xFFFFD166),
                                fontSize = 12.sp
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(when(selectedTab) {
                            "Upcoming" -> "UPCOMING MATCHES"
                            "Results" -> "RECENT RESULTS"
                            else -> "MATCH CENTRE"
                        }, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    items(demoMatches.filter {
                        when(selectedTab) {
                            "Upcoming" -> it.status.contains("UPCOMING")
                            "Results" -> it.status.contains("RESULT")
                            else -> it.status.contains("LIVE")
                        }
                    }) { match ->
                        MatchCard(match) { selectedMatch = match }
                    }
                    item { Spacer(Modifier.height(20.dp)) }
                }
            }
        }
    }
}

@Composable
private fun MatchCard(match: MatchItem, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(match.title, color = Muted, fontSize = 12.sp)
                Text(match.status, color = Green, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text(match.team1, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(match.score1, color = Muted)
                }
                Text("VS", color = Green, fontWeight = FontWeight.Bold)
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text(match.team2, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(match.score2, color = Muted)
                }
            }
            HorizontalDivider(color = Color(0xFF2B3A4E))
            Text(match.detail, color = Muted, fontSize = 13.sp)
            Text("Tap for details  →", color = Green, fontSize = 12.sp)
        }
    }
}

@Composable
private fun MatchDetail(match: MatchItem, modifier: Modifier = Modifier, onBack: () -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("‹ Back", color = Green, modifier = Modifier.clickable { onBack() })
        Text("MATCH SCORECARD", fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text(match.title, color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Card)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(match.status, color = Green, fontWeight = FontWeight.Bold)
                Text("${match.team1}   ${match.score1}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("${match.team2}   ${match.score2}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(match.detail, color = Muted)
                Text("Detailed ball-by-ball data will be available after a real cricket API is connected.", color = Muted)
            }
        }
    }
}
