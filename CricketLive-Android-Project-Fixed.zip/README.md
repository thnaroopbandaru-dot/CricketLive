# Cricket Live Android project

This is a minimal native Android app project using Kotlin and Jetpack Compose.
The displayed scores are DEMO examples and are not real-time cricket data.
A licensed/authorized cricket data API must be connected before presenting real live scores.

## Build
Requires JDK 17, Gradle 8.9, and Android SDK Platform 35.
Run:
`gradle assembleDebug`
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

This project does not include an API key and does not yet fetch real live scores.
